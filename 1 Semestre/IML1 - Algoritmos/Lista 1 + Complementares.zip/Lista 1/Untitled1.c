#include <stdio.h>
main()
    {
    float n;
     printf("Informe um numero para saber o seu sucessor e antecessor: ");
     scanf("%f" , & n);

     printf("\nO Antecessor de %f",n);
     printf(" e %f",n-1);

     printf("\nO Sucessor de %f",n);
     printf(" e %f",n+1);


     printf("\n");

    }
